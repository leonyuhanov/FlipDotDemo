using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlipDotScript : MonoBehaviour
{
    public GameObject[] sourceDot;
	GameObject[] flipDots;
	Vector3 frontDotPosition = new Vector3(-1f, 0, -1f);
	float xIncrement=1;
	int dotCount=0, xCount=0, yCount=0;
	const int dotWidth = 60, dotHeight=40;
	const int numberOfDots = dotWidth*dotHeight;
	VBitmap mainFrame = new VBitmap(dotWidth,dotHeight);
	byte[] tempBC = new byte[3];
	WebCamTexture WCTexture;
	byte maxValue = 250;
	
	// Start is called before the first frame update
    void Start()
    {
		flipDots = new GameObject[numberOfDots];
		
		for(yCount=0; yCount<dotHeight; yCount++)
		{
			for(xCount=0; xCount<dotWidth; xCount++)
			{
				flipDots[dotCount] = GameObject.Instantiate(sourceDot[0]);
				frontDotPosition.x = frontDotPosition.x+xIncrement;
				flipDots[dotCount].transform.position = frontDotPosition;
				flipDots[dotCount].name = "DOT_"+xCount+"_"+yCount;
				dotCount++;
			}
			frontDotPosition.x = -1f;
			frontDotPosition.y = frontDotPosition.y-1;

		}
		
		Destroy(sourceDot[0]);
		
		WCTexture = new WebCamTexture("Integrated Webcam", 640, 480);
		WCTexture.Play();
		Debug.Log("Webcam Texture is "+WCTexture.width+"W x "+WCTexture.height+"H");
		
		
    }

    // Update is called once per frame
    void Update()
    {
		int hBlockSize = WCTexture.width/dotWidth;
		int vBlockSize = WCTexture.height/dotHeight;
		int hBlockCount=0, vBlockCount=0;
		int numberOfPxPerBlock = hBlockSize*vBlockSize;
		long pxColourTotal=0;
				
		for(yCount=0; yCount<dotHeight; yCount++)
		{
			for(xCount=0; xCount<dotWidth; xCount++)
			{
				
				for(vBlockCount=yCount*vBlockSize; vBlockCount<(yCount*vBlockSize)+vBlockSize; vBlockCount++)
				{	
					for(hBlockCount=xCount*hBlockSize; hBlockCount<(xCount*hBlockSize)+hBlockSize; hBlockCount++)
					{
						pxColourTotal += getLargestRGBValue(WCTexture.GetPixel(hBlockCount, vBlockCount));
					}
				}
				pxColourTotal = pxColourTotal/numberOfPxPerBlock;
				tempBC[0] = (byte)pxColourTotal;
				mainFrame.drawPixel(xCount, yCount, tempBC);
			}
		}
		renderFlipDots();
    }
	
	byte getLargestRGBValue(Color pixelColour)
	{
		byte largestValue=0;
		if(largestValue<pixelColour.r)
		{
			largestValue = (byte)(pixelColour.r*maxValue);
		}
		if(largestValue<pixelColour.g)
		{
			largestValue = (byte)(pixelColour.g*maxValue);
		}
		if(largestValue<pixelColour.b)
		{
			largestValue = (byte)(pixelColour.b*maxValue);
		}
		return largestValue;
	}
	
	void setRotationViaColour(GameObject anObject, int cValue, int scaleTo)
	{
		float rotationAngle = 90+(((float)(cValue%scaleTo)/scaleTo)*180);
		anObject.transform.localRotation = Quaternion.Euler(rotationAngle, 0, 0);
	}
	
	void renderFlipDots()
	{	
		int dotIndex=0;
		for(yCount=0; yCount<dotHeight; yCount++)
		{
			for(xCount=0; xCount<dotWidth; xCount++)
			{
				setRotationViaColour(flipDots[dotIndex],VBitmap.vBuffer[yCount, xCount, 0], maxValue);
				dotIndex++;
			}
		}
	}
}

public class VBitmap
{
	public static byte[,,] vBuffer;
	int bufferWidth;
	int bufferHeight;
	
	public VBitmap(int width, int height)
    {
		bufferWidth = width;
		bufferHeight = height;
		vBuffer = new byte[height, width, 3];
    }
	
	public void drawPixel(int x, int y, byte[] pcolour)
	{
		if(checkBounds(x, y)==1)
		{
			vBuffer[y, x, 0] = pcolour[0];
			vBuffer[y, x, 1] = pcolour[1];
			vBuffer[y, x, 2] = pcolour[2];
		}
	}
	
	public void clear()
	{
		int xCount, yCount;
		for(yCount=0; yCount<bufferHeight; yCount++)
		{
			for(xCount=0; xCount<bufferWidth; xCount++)
			{
				vBuffer[yCount, xCount, 0] = 0;
				vBuffer[yCount, xCount, 1] = 0;
				vBuffer[yCount, xCount, 2] = 0;
			}
		}
	}
	
	public byte checkBounds(int x, int y)
	{
		if(x>=0 && x<bufferWidth && y>=0 && y<bufferHeight)
		{
			return 1;
		}
		else 
		{
			return 0;
		}
	}
}